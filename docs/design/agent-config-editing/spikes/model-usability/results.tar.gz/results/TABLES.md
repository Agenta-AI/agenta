### Correct final configuration, by task

| Task | What it asks | Haiku v0 | Haiku v1 | Haiku v2 | Haiku v2+L | DS v0 | DS v1 | DS v2 | DS v2+L |
|---|---|---|---|---|---|---|---|---|---|
| a | edit one instruction sentence | 5/5 | 5/5 | 5/5 | 5/5 | 4/5 | 3/5 | 5/5 | 5/5 |
| b | change one line in one skill body | 1/5 | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| c | add one tool by name | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| d | remove one MCP server | 0/5 | 5/5 | 5/5 | 5/5 | 2/5 | 5/5 | 5/5 | 5/5 |
| e | add a skill from workspace files | 0/5 | 5/5 | 5/5 | 5/5 | 3/5 | 5/5 | 5/5 | 5/5 |
| f | conflict, then retry on the new head | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 | 3/5 | 5/5 | 5/5 |
| g | ambiguous anchor, then retry with more context | 2/5 | 5/5 | 5/5 | 5/5 | 3/5 | 5/5 | 5/5 | 5/5 |
| h | import from the wrong folder, then correct the path | 0/5 | 5/5 | 3/5 | 5/5 | 3/5 | 5/5 | 4/5 | 4/5 |
| i | rename a skill, keeping its content | 0/5 | 2/5 | 5/5 | 5/5 | 4/5 | 4/5 | 5/5 | 5/5 |
| j | edit a line inside a bundled skill file | 0/5 | 1/5 | 5/5 | 5/5 | 4/5 | 5/5 | 5/5 | 5/5 |
| k | three changes in one commit | 1/5 | 5/5 | 5/5 | 5/5 | 4/5 | 4/5 | 5/5 | 5/5 |
| **all** | | **19/55** | **48/55** | **53/55** | **55/55** | **42/55** | **49/55** | **54/55** | **54/55** |

### Pipeline rates (all tasks pooled)

| Arm | n | called the tool | valid JSON (first call) | engine accepted | correct |
|---|---|---|---|---|---|
| Haiku v0 | 55 | 55/55 (100%) | 55/55 (100%) | 29/55 (52%) | 19/55 (34%) |
| Haiku v1 | 55 | 55/55 (100%) | 55/55 (100%) | 48/55 (87%) | 48/55 (87%) |
| Haiku v2 | 55 | 55/55 (100%) | 55/55 (100%) | 53/55 (96%) | 53/55 (96%) |
| Haiku v2+L | 55 | 55/55 (100%) | 55/55 (100%) | 55/55 (100%) | 55/55 (100%) |
| DS v0 | 55 | 53/55 (96%) | 53/55 (96%) | 44/55 (80%) | 42/55 (76%) |
| DS v1 | 55 | 55/55 (100%) | 55/55 (100%) | 49/55 (89%) | 49/55 (89%) |
| DS v2 | 55 | 55/55 (100%) | 55/55 (100%) | 55/55 (100%) | 54/55 (98%) |
| DS v2+L | 55 | 55/55 (100%) | 55/55 (100%) | 54/55 (98%) | 54/55 (98%) |

### Recovery tasks: did the model fix itself within two retries?

| Arm | f (409 conflict) | g (ambiguous anchor) | h (wrong folder) |
|---|---|---|---|
| Haiku v0 | 0 first call, 5 after retry, 0 never | 0 first call, 2 after retry, 3 never | 0 first call, 0 after retry, 5 never |
| Haiku v1 | 0 first call, 5 after retry, 0 never | 2 first call, 3 after retry, 0 never | 0 first call, 5 after retry, 0 never |
| Haiku v2 | 0 first call, 5 after retry, 0 never | 5 first call, 0 after retry, 0 never | 0 first call, 3 after retry, 2 never |
| Haiku v2+L | 0 first call, 5 after retry, 0 never | 5 first call, 0 after retry, 0 never | 0 first call, 5 after retry, 0 never |
| DS v0 | 0 first call, 5 after retry, 0 never | 0 first call, 3 after retry, 2 never | 0 first call, 3 after retry, 2 never |
| DS v1 | 0 first call, 3 after retry, 2 never | 5 first call, 0 after retry, 0 never | 0 first call, 5 after retry, 0 never |
| DS v2 | 0 first call, 5 after retry, 0 never | 4 first call, 1 after retry, 0 never | 0 first call, 4 after retry, 1 never |
| DS v2+L | 0 first call, 5 after retry, 0 never | 5 first call, 0 after retry, 0 never | 0 first call, 4 after retry, 1 never |

### Cost

| Arm | input tokens | output tokens |
|---|---|---|
| Haiku v0 | 360,099 | 26,769 |
| Haiku v1 | 300,346 | 23,074 |
| Haiku v2 | 217,978 | 16,488 |
| Haiku v2+L | 200,593 | 15,399 |
| DS v0 | 280,866 | 51,945 |
| DS v1 | 208,559 | 36,356 |
| DS v2 | 176,481 | 23,441 |
| DS v2+L | 173,647 | 22,628 |
