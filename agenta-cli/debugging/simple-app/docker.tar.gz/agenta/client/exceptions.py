class APIRequestError(Exception):
    """Exception to be raised when an API request fails."""
