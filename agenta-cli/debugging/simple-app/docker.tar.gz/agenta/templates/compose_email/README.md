# Using this template

Please make sure to create a `.env` file with your OpenAI API key before running the app.
OPENAI_API_KEY=sk-xxxxxxx

You can find your keys here:
https://platform.openai.com/account/api-keys

Go back to the [Getting started tutorial](https://docs.agenta.ai/getting-started) to continue